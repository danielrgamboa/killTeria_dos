package killTeria_dos;


import java.util.Random;

import processing.core.PApplet;
import processing.core.PImage;

public class Enemigo extends Thread {

	private PApplet app;

	public int columna;
	private int x;
	private int y = 38;
	private PImage enemigo;
	private Logica logi;

	public Enemigo(PApplet p, int i) {

		this.app = p;
		
		Random rnd = new Random();
		int random = rnd.nextInt(3) +1;
		switch (random) {
		case 1:

			this.enemigo = app.loadImage("malo0.png");
			break;
		case 2:

			this.enemigo = app.loadImage("malo1.png");
			break;
			
		case 3:

			this.enemigo = app.loadImage("malo2.png");
			break;
		}
		
		
		this.columna = i;

		switch (columna) {

		case 1:
			this.x = 135;
			break;

		case 2:
			this.x = 304;
			break;

		case 3:
			this.x = 468;
			break;

		case 4:

			this.x = 625;
			break;

		case 5:
			this.x = 779;

			break;

		case 6:

			this.x = 940;
			break;

		}


		 app.image(enemigo, x, y, 80, 80);
	}

	// hilo
	public void run() {
		while (true) {
			try {
				sleep(20);
				this.y = this.y+3;
				
				
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			
			
		}
	}
	
	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public void pintar() {
		app.image(enemigo, x, y, 100, 100);
	
	}

}
