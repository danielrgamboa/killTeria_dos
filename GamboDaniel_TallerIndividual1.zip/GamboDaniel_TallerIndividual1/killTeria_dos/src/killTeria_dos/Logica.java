package killTeria_dos;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Observable;
import java.util.Observer;
import java.util.Random;

import processing.core.PApplet;
import processing.core.PImage;

public class Logica implements Observer {
	private PApplet app;
	
	//img
	private PImage  fin, inicio, juego, globino;
		
	private int pantalla;
	private int kill = 144;
	private ArrayList <ArrayList> enemigos; 
	
	private ControlServidor conexion;
	private long start ;
	private int i;
	private long nowMillis;

	private long inicioJuego;

	private long tiempoPerdida;
	
	public Logica (PApplet app) {

		this.app = app;
		 pantalla = 1;
		 
		 conexion = ControlServidor.iniciarConexion();
		 conexion.addObserver(this);
	//Subir
		 
		//Enemigos
		//ENEMIGOS ARREGLOS
		 	enemigos = new ArrayList<ArrayList>();
			
			// Imagenes de los Globulos
			globino = app.loadImage("hombre.png");
			
			// Imagenes de las Pantallas
			inicio = app.loadImage("inicio.png");
			juego = app.loadImage("juego.png");
			fin = app.loadImage("final.png");
			
			start =  System.currentTimeMillis();
			
	}

	
	
	
	
	public void cargarEnemigos() {
		
		//while (enemigos.size()<5) {
			
			Random rnd = new Random();
			int cantidadEnemigos = rnd.nextInt(5)+1;
			

			ArrayList<Enemigo> enemigosPorFila = new ArrayList<Enemigo>();
			
			ArrayList<Integer> posiciones = new ArrayList<Integer> ();
			posiciones.add(1);
			posiciones.add(2);
			posiciones.add(3);
			posiciones.add(4);
			posiciones.add(5);
			posiciones.add(6);
			
			
			Collections.shuffle(posiciones);
			
			for (int i = 0 ; i <cantidadEnemigos; i ++) {
				
				Enemigo a = new Enemigo (app, posiciones.get(i));
				a.start();
				enemigosPorFila.add(a);
				
				
				
								
			}
			
			
			enemigos.add(enemigosPorFila);
			start = System.currentTimeMillis();
		
		
		int x = 0 ;
		x++;
			
			
			
		

		
	}

	
//DRAW
	public void pintar() {

		switch(pantalla) {
		
		
		case 1:
			app.image(inicio,0,0,1200,700);
	
			break;

		
		case 2:
			
			
			app.image(juego,0,0,1200,700);
	

			app.text((System.currentTimeMillis()-inicioJuego)/1000+"", 60,410);
			System.out.println("pantalla = 2");

			
			app.image(globino,kill,558,100,100);
		
			
			
			nowMillis = System.currentTimeMillis();
			long tiempo = nowMillis-start;
			if(tiempo > 2000) {
				cargarEnemigos();
				
			}
			
			
			for (int i = 0 ; i<enemigos.size()  ; i ++) {

				
				
				ArrayList<Enemigo>listaEnemigos=  enemigos.get(i);
				
				
			  
				
				for(int j = 0 ; j< listaEnemigos.size() ; j++) {
					
					
					listaEnemigos.get(j).pintar();
					
					int yEnemy=listaEnemigos.get(j).getY();
					
					int xEnemy=listaEnemigos.get(j).getX();
					
					System.out.println(kill);
					System.out.println(yEnemy);
					System.out.println(xEnemy);
					
					if((yEnemy>500  && yEnemy<657)	&& ((kill >= xEnemy && kill <= xEnemy+80)  || (kill+100>= xEnemy && kill+100 <= xEnemy+80)  )) {
					
						pantalla=3;
						tiempoPerdida = System.currentTimeMillis();
					}
					
			}
			}
		
			    	 
			     
			     
			
			
			
			
			break;
		
		case 3:
			app.image(fin,0,0,1200,700);
			
			
			app.text("Tiempo: " + (tiempoPerdida-inicioJuego)/1000, 550,400);
			
			break;
		}
		
		app.fill(0);
       
	}

	
	
//MOUSEPRESSED	
	

	@Override
	public void update(Observable o, Object arg) {
		
		
		
		String mensaje = (String) arg;
		
		if (mensaje.matches("S") && pantalla ==1) {
			
			System.out.println(pantalla + "pantalla 2");
			pantalla = 2;
			inicioJuego = System.currentTimeMillis();
		}
		
		if (pantalla == 2) {
			if (mensaje.matches("D") && kill <= 902) {
				kill= kill+162;
			}
			if (mensaje.matches("I") && kill >= 306) {
				kill= kill-162;
			}
			
			
		}
		
		
		if (pantalla == 3 && mensaje.matches("S")){
			
			enemigos.clear();
			pantalla =2;

			inicioJuego = System.currentTimeMillis();
		}
		
		
	}
		
	
		
}
