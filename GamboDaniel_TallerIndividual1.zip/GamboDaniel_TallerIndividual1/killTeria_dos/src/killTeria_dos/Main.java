package killTeria_dos;

import processing.core.PApplet;

//ESTE CODIGO SE HIZO EN COMPANIA DE LINA VASQUEZ Y CAMILA MORA, con la ayuda del hermano de Lina.  

public class Main extends PApplet {
	
	private Logica logi;

	public static void main(String[] args) {
		PApplet.main("killTeria_dos.Main");

	}
	
	public void settings() {
		size(1200,700);
	}
	
	public void setup() {
		logi = new Logica(this);
	}
	
	public void draw() {
		background(255,255,255);
		logi.pintar();
	}
	
	

}