package com.example.talle1eco;

import androidx.appcompat.app.AppCompatActivity;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import java.util.Observable;
import java.util.Observer;

public class Control extends AppCompatActivity implements Observer {

    private ImageButton arriba;
    private ImageButton abajo;
    private ImageButton disparar;
    private ImageButton returncontrol;
    private ImageButton pausa;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_control);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_USER_LANDSCAPE);

        final Comunication conexion = Comunication.getRef();
        conexion.addObserver(this);

        arriba =findViewById(R.id.btn_arriba);
        abajo =findViewById(R.id.btn_abajo);
        disparar =findViewById(R.id.btn_disparar);



        arriba.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                conexion.enviar("I");
            }
        });

        abajo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                conexion.enviar("D");
            }
        });

        disparar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                conexion.enviar("S");
            }
        });






    }

    @Override
    public void update(Observable o, Object arg) {

    }
}
