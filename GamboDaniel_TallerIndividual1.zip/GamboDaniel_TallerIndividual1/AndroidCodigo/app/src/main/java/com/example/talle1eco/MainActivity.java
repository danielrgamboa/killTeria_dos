package com.example.talle1eco;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.Observable;
import java.util.Observer;

public class MainActivity extends AppCompatActivity  implements Observer {

    private EditText nombre;
    private EditText ip;
    private Button empezar;

    @Override
    public void update(Observable o, Object arg) {

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);


        nombre = findViewById(R.id.et_nombre);
        ip = findViewById(R.id.et_ip);
        empezar = findViewById(R.id.bt_enviar);

        final Comunication conexion = Comunication.getRef();
        conexion.addObserver(this);


        empezar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                conexion.crearConexion(ip.getText().toString());
                Intent i = new Intent(MainActivity.this, Control.class);
                startActivity(i);


            }
        });


    }
}
